package com.example.akosombotour;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class EthnicgroupsFragment extends Fragment {
    ListView listView;

    public EthnicgroupsFragment() {
        //constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.list_item, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        EthnicgroupsModel.getUsers(getActivity());
        listView = view.findViewById(R.id.lvUsers);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 1) {
                    Toast.makeText(getActivity(), "Ewes are 45.8% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 2) {
                    Toast.makeText(getActivity(), "Adangbes are 28..1% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 3) {
                    Toast.makeText(getActivity(), "Akans are 11.6% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 5) {
                    Toast.makeText(getActivity(), "Christianity is the major region with", Toast.LENGTH_SHORT).show();
                }
                if (i == 6) {
                    Toast.makeText(getActivity(), "Islam is the second major region with", Toast.LENGTH_SHORT).show();
                }
                if (i == 7) {
                    Toast.makeText(getActivity(), "The Traditional worshippers are the minority", Toast.LENGTH_SHORT).show();
                }

            }
        });

        populateUsersList(view);

    }

    private void populateUsersList(View view) {
        // Construct the data source
        ArrayList<EthnicgroupsModel> arrayOfUsers = EthnicgroupsModel.getUsers(getActivity());
        // Create the adapter to convert the array to views
        EthnicgroupsAdapter adapter = new EthnicgroupsAdapter(getContext(), arrayOfUsers);
        // Attach the adapter to a ListView
        listView.setAdapter(adapter);
    }
}